﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Details
{
    public partial class AuthForm : Form
    {
        public AuthForm()
        {
            InitializeComponent();
        }

        private void AuthForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = tblogin.Text;
            string password = tbpassword.Text;
            List<User> users = Entities.GetContext().User.ToList();
            User u = users.FirstOrDefault(p => p.login == login && p.password == password);
            if (u != null)
            {
                detailsMain mainWindow = new detailsMain(1);
                mainWindow.Owner = this;
                this.Hide();
                mainWindow.Show();
            }
            else
            {
                MessageBox.Show("Неправильно ввели логин или пароль", "Попробуйте еще раз!");
            }
        }

        private void lbreg_MouseHover(object sender, EventArgs e)
        {
            lbreg.ForeColor = Color.Gray;
        }

        private void lbreg_MouseLeave(object sender, EventArgs e)
        {
            lbreg.ForeColor = Color.Black;
        }

        private void butout_Click(object sender, EventArgs e)
        {
            detailsMain mainWindow = new detailsMain(0);
            mainWindow.Owner = this;
            this.Hide();
            mainWindow.Show();
        }

        private void lbreg_Click(object sender, EventArgs e)
        {
            Regist r = new Regist();
            this.Hide();
            r.Show();
        }

        private void AuthForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
