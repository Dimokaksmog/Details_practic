﻿namespace Details
{
    partial class AuthForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.butauth = new System.Windows.Forms.Button();
            this.tblogin = new System.Windows.Forms.TextBox();
            this.tbpassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.butout = new System.Windows.Forms.Button();
            this.lbreg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // butauth
            // 
            this.butauth.Location = new System.Drawing.Point(11, 103);
            this.butauth.Name = "butauth";
            this.butauth.Size = new System.Drawing.Size(99, 46);
            this.butauth.TabIndex = 0;
            this.butauth.Text = "Авторизоваться";
            this.butauth.UseVisualStyleBackColor = true;
            this.butauth.Click += new System.EventHandler(this.button1_Click);
            // 
            // tblogin
            // 
            this.tblogin.Location = new System.Drawing.Point(11, 27);
            this.tblogin.Name = "tblogin";
            this.tblogin.Size = new System.Drawing.Size(199, 20);
            this.tblogin.TabIndex = 1;
            // 
            // tbpassword
            // 
            this.tbpassword.Location = new System.Drawing.Point(11, 77);
            this.tbpassword.Name = "tbpassword";
            this.tbpassword.Size = new System.Drawing.Size(199, 20);
            this.tbpassword.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Пароль";
            // 
            // butout
            // 
            this.butout.Location = new System.Drawing.Point(116, 103);
            this.butout.Name = "butout";
            this.butout.Size = new System.Drawing.Size(94, 46);
            this.butout.TabIndex = 5;
            this.butout.Text = "Выйти в меню";
            this.butout.UseVisualStyleBackColor = true;
            this.butout.Click += new System.EventHandler(this.butout_Click);
            // 
            // lbreg
            // 
            this.lbreg.AutoSize = true;
            this.lbreg.Location = new System.Drawing.Point(51, 152);
            this.lbreg.Name = "lbreg";
            this.lbreg.Size = new System.Drawing.Size(119, 13);
            this.lbreg.TabIndex = 6;
            this.lbreg.Text = "Зарегистрироваться?";
            this.lbreg.Click += new System.EventHandler(this.lbreg_Click);
            this.lbreg.MouseLeave += new System.EventHandler(this.lbreg_MouseLeave);
            this.lbreg.MouseHover += new System.EventHandler(this.lbreg_MouseHover);
            // 
            // AuthForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(222, 172);
            this.Controls.Add(this.lbreg);
            this.Controls.Add(this.butout);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbpassword);
            this.Controls.Add(this.tblogin);
            this.Controls.Add(this.butauth);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AuthForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AuthForm_FormClosing);
            this.Load += new System.EventHandler(this.AuthForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button butauth;
        private System.Windows.Forms.TextBox tblogin;
        private System.Windows.Forms.TextBox tbpassword;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button butout;
        private System.Windows.Forms.Label lbreg;
    }
}