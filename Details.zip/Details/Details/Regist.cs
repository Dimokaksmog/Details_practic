﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Details
{
    public partial class Regist : Form
    {
        public Regist()
        {
            InitializeComponent();
        }

        private void Regist_Load(object sender, EventArgs e)
        {

        }

        private void lbout_MouseHover(object sender, EventArgs e)
        {
            lbout.ForeColor = Color.Gray;
        }

        private void lbout_MouseLeave(object sender, EventArgs e)
        {
            lbout.ForeColor = Color.Black;

        }

        private void butreg_Click(object sender, EventArgs e)
        {
            try
            {
                Entities con = new Entities();
                User u = new User();
                u.login = tblogin.Text;
                u.password = tbpassword.Text;
                con.User.Add(u);
                con.SaveChanges();
                MessageBox.Show("Вы успешно зарегистрировались", "Сообщение");
                AuthForm h = new AuthForm();
                this.Hide();
                h.Show();

            }
            catch (Exception)
            {
                MessageBox.Show("Неудалось зарегистрироваться", "Ошибка");
                throw;
            }
            
        }

        private void lbout_Click(object sender, EventArgs e)
        {
            detailsMain d = new detailsMain(0);
            this.Hide();
            d.Show();
        }

        private void Regist_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
