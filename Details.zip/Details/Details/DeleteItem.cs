﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Details
{
    public partial class DeleteItem : Form
    {
        public DeleteItem()
        {
            InitializeComponent();
            var del = Entities.GetContext().ItemStock.OrderBy(p => p.Name).ToList();
            cbdel.DataSource = del;
            cbdel.DisplayMember = "Name";
            cbdel.ValueMember = "id_item";
        }

        private void butdel_Click(object sender, EventArgs e)
        {
            var item = Entities.GetContext();
            var ItemToDel = item.ItemStock.Where(p => p.Name.Contains(cbdel.Text)).FirstOrDefault();
            try
            {
                item.ItemStock.Remove(ItemToDel);
                item.SaveChanges();
                MessageBox.Show("Деталь удалена!","Сообщение");
            }
            catch (Exception)
            {
                MessageBox.Show("Деталь не удалена!","Ошибка");
                throw;
            }
        }
    }
}
