﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Details
{
    public partial class detailsMain : Form
    {
        public detailsMain(int auth)
        {
            InitializeComponent();
            if (auth == 1)
            {
                butadd.Enabled = true;
                butdel.Enabled = true;
                butedit.Enabled = true;
                butauth.Enabled = false;
                butauth.Text = "Вы уже авторизировались!";
            }
            UpdateTable();
        }

        private void butadd_Click(object sender, EventArgs e)
        {
            AddItems open = new AddItems();
            open.Show();
        }

        private void butdel_Click(object sender, EventArgs e)
        {
            DeleteItem delete = new DeleteItem();
            delete.Show();
        }

        private void butedit_Click(object sender, EventArgs e)
        {
            EditItem edit = new EditItem();
            edit.Show();
        }

        private void butExcel_Click(object sender, EventArgs e)
        {
            Excel.Application exApp = new Excel.Application();
            exApp.Workbooks.Add();
            Excel.Worksheet wsh = (Excel.Worksheet)exApp.ActiveSheet;
            wsh.Name = "Все детали";
            int i, j;
            for (i = 0; i <= dtgCatalog.ColumnCount - 1; i++)
            {
                wsh.Cells[1, i + 1] = dtgCatalog.Columns[i].HeaderCell.Value;
            }
            for (i = 0; i <= dtgCatalog.RowCount - 1; i++)
            {
                for (j = 0; j <= dtgCatalog.ColumnCount - 1; j++)
                {
                    wsh.Cells[i + 2, j + 1] = dtgCatalog[j, i].Value.ToString();
                }
            }
            exApp.Visible = true;
        }

        private void detailsMain_Load(object sender, EventArgs e)
        {

        }
        private void UpdateTable()
        {
            var detailsort = Entities.GetContext().ItemStock.ToList();
            dtgCatalog.DataSource = detailsort;
            dtgCatalog.Columns[0].HeaderText = "Номер детали на складе";
            dtgCatalog.Columns[1].HeaderText = "Название";
            dtgCatalog.Columns[2].HeaderText = "Модель";
            dtgCatalog.Columns[3].HeaderText = "Длинна (мм)";
            dtgCatalog.Columns[4].HeaderText = "Ширина (мм)";
            dtgCatalog.Columns[5].HeaderText = "Высота (мм)";
            dtgCatalog.Columns[6].HeaderText = "Количество";
        }
        private void UpdateSort() 
        {
            var currentGoods = Entities.GetContext().ItemStock.ToList();
            currentGoods = currentGoods.Where(p => p.Name.ToLower().Contains(tbpoiskname.Text.ToLower())).ToList();
            currentGoods = currentGoods.Where(p => p.Model.ToLower().Contains(tbpoiskmodel.Text.ToLower())).ToList();
            if (cbnamesort.SelectedIndex > 0)
            {
                if (cbnamesort.SelectedIndex == 1)
                {
                    currentGoods = currentGoods.OrderBy(p => p.Name).ToList();
                }
                if (cbnamesort.SelectedIndex == 2)
                {
                    currentGoods = currentGoods.OrderByDescending(p => p.Name).ToList();
                }
            }
            if (cbmodelsort.SelectedIndex > 0)
            {
                if (cbmodelsort.SelectedIndex == 1)
                {
                    currentGoods = currentGoods.OrderBy(p => p.Model).ToList();
                }
                if (cbmodelsort.SelectedIndex == 2)
                {
                    currentGoods = currentGoods.OrderByDescending(p => p.Model).ToList();
                }
            }
            dtgCatalog.DataSource = currentGoods;
        }

        private void butauth_Click(object sender, EventArgs e)
        {
            AuthForm auth = new AuthForm();
            this.Hide();
            auth.Show();
        }

        private void tbpoiskname_TextChanged(object sender, EventArgs e)
        {
            UpdateSort();
        }

        private void tbpoiskmodel_TextChanged(object sender, EventArgs e)
        {
            UpdateSort();
        }

        private void cbnamesort_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateSort();
        }

        private void cbmodelsort_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateSort();
        }

        private void butupdate_Click(object sender, EventArgs e)
        {
            UpdateSort();
        }

        private void detailsMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
