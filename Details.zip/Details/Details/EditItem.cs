﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Details
{
    public partial class EditItem : Form
    {
        public EditItem()
        {
            InitializeComponent();
            var del = Entities.GetContext().ItemStock.OrderBy(p => p.id_item).ToList();
            cbedit.DataSource = del;
            cbedit.DisplayMember = "id_item";
            cbedit.ValueMember = "id_item";
        }
        private void cbedit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbedit.SelectedValue is int selectedId)
            {
                // Находим элемент в базе данных по его id
                var grou = Entities.GetContext().ItemStock.Find(selectedId);
                if (grou != null)
                {
                    tbname.Text = grou.Name;
                    tbmodel.Text = grou.Model;
                    tblength.Text = grou.Length.ToString();
                    tbwidth.Text = grou.Width.ToString();
                    tbheight.Text = grou.Height.ToString();
                    tbcount.Text = grou.Count.ToString();
                }
            }
            //var grou = Entities.GetContext().ItemStock.Find(cbedit.SelectedItem);
            //if (grou != null)
            //{
            //    tbname.Text = grou.Name;
            //    tbmodel.Text = grou.Model;
            //    tblength.Text = grou.Length.ToString();
            //    tbwidth.Text = grou.Width.ToString();
            //    tbheight.Text = grou.Height.ToString();
            //    tbcount.Text = grou.Count.ToString();
            //}
        }
        private void butedit_Click(object sender, EventArgs e)
        {
            try
            {
                if (cbedit.SelectedValue is int selectedId)
                {
                    var grou = Entities.GetContext().ItemStock.Find(selectedId);
                    if (grou != null)
                    {
                        // Обновляем свойства элемента на основе значений в текстовых полях
                        grou.Name = tbname.Text;
                        grou.Model = tbmodel.Text;
                        grou.Length = double.Parse(tblength.Text);
                        grou.Width = double.Parse(tbwidth.Text);
                        grou.Height = double.Parse(tbheight.Text);
                        grou.Count = int.Parse(tbcount.Text);

                        // Сохраняем изменения в базу данных
                        Entities.GetContext().SaveChanges();
                        MessageBox.Show("Изменения сохранены.");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("");
                throw;
            }
            
        }

        private void butclear_Click(object sender, EventArgs e)
        {
            tbname.Text = "";
            tbmodel.Text = "";
            tblength.Text = "";
            tbwidth.Text = "";
            tbheight.Text = "";
            tbcount.Text = "";
            cbedit.SelectedIndex = -1;
        }
    }
}
