﻿namespace Details
{
    partial class Regist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblogin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbpassword = new System.Windows.Forms.TextBox();
            this.butreg = new System.Windows.Forms.Button();
            this.lbout = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tblogin
            // 
            this.tblogin.Location = new System.Drawing.Point(12, 25);
            this.tblogin.Name = "tblogin";
            this.tblogin.Size = new System.Drawing.Size(184, 20);
            this.tblogin.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Пароль";
            // 
            // tbpassword
            // 
            this.tbpassword.Location = new System.Drawing.Point(12, 64);
            this.tbpassword.Name = "tbpassword";
            this.tbpassword.Size = new System.Drawing.Size(184, 20);
            this.tbpassword.TabIndex = 2;
            // 
            // butreg
            // 
            this.butreg.Location = new System.Drawing.Point(15, 90);
            this.butreg.Name = "butreg";
            this.butreg.Size = new System.Drawing.Size(181, 40);
            this.butreg.TabIndex = 4;
            this.butreg.Text = "Зарегистрироваться";
            this.butreg.UseVisualStyleBackColor = true;
            this.butreg.Click += new System.EventHandler(this.butreg_Click);
            // 
            // lbout
            // 
            this.lbout.AutoSize = true;
            this.lbout.Location = new System.Drawing.Point(36, 133);
            this.lbout.Name = "lbout";
            this.lbout.Size = new System.Drawing.Size(146, 13);
            this.lbout.TabIndex = 5;
            this.lbout.Text = "Войти, у меня есть аккаунт";
            this.lbout.Click += new System.EventHandler(this.lbout_Click);
            this.lbout.MouseLeave += new System.EventHandler(this.lbout_MouseLeave);
            this.lbout.MouseHover += new System.EventHandler(this.lbout_MouseHover);
            // 
            // Regist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(209, 153);
            this.Controls.Add(this.lbout);
            this.Controls.Add(this.butreg);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbpassword);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tblogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Regist";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Регистрация";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Regist_FormClosing);
            this.Load += new System.EventHandler(this.Regist_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tblogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbpassword;
        private System.Windows.Forms.Button butreg;
        private System.Windows.Forms.Label lbout;
    }
}