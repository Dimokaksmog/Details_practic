﻿namespace Details
{
    partial class DeleteItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbdel = new System.Windows.Forms.ComboBox();
            this.butdel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cbdel
            // 
            this.cbdel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbdel.FormattingEnabled = true;
            this.cbdel.Location = new System.Drawing.Point(12, 12);
            this.cbdel.Name = "cbdel";
            this.cbdel.Size = new System.Drawing.Size(341, 21);
            this.cbdel.TabIndex = 0;
            // 
            // butdel
            // 
            this.butdel.Location = new System.Drawing.Point(12, 39);
            this.butdel.Name = "butdel";
            this.butdel.Size = new System.Drawing.Size(341, 37);
            this.butdel.TabIndex = 1;
            this.butdel.Text = "Удалить эту деталь полностью";
            this.butdel.UseVisualStyleBackColor = true;
            this.butdel.Click += new System.EventHandler(this.butdel_Click);
            // 
            // DeleteItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 94);
            this.Controls.Add(this.butdel);
            this.Controls.Add(this.cbdel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "DeleteItem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Удаление деталь";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbdel;
        private System.Windows.Forms.Button butdel;
    }
}