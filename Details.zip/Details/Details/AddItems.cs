﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Details
{
    public partial class AddItems : Form
    {
        public AddItems()
        {
            InitializeComponent();
        }

        private void butadd_Click(object sender, EventArgs e)
        {
            try
            {
                Entities con = new Entities();
                ItemStock u = new ItemStock();
                u.Name = tbname.Text;
                u.Model = tbmodel.Text;
                u.Length = Convert.ToDouble(tblength.Text);
                u.Width = Convert.ToDouble(tbwidth.Text);
                u.Height = Convert.ToDouble(tbheight.Text);
                u.Count = Convert.ToInt32(tbcount.Text);
                con.ItemStock.Add(u);
                con.SaveChanges();
                MessageBox.Show("Добавили новую деталь на склад!", "Сообщение");
            }
            catch (Exception)
            {
                MessageBox.Show("Неправильно заполнены данные!", "Сообщение");
                throw;
            }
            
        }

        private void butclear_Click(object sender, EventArgs e)
        {
            tbname.Text = "";
            tbmodel.Text = "";
            tblength.Text = "";
            tbwidth.Text = "";
            tbheight.Text = "";
            tbcount.Text = "";
        }

        private void tblength_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && (tblength.Text.IndexOf(',') > -1 || tblength.Text.Length == 0))
            {
                e.Handled = true;
            }
        }

        private void tbwidth_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && (tbwidth.Text.IndexOf(',') > -1 || tbwidth.Text.Length == 0))
            {
                e.Handled = true;
            }
        }

        private void tbheight_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ',')
            {
                e.Handled = true;
            }
            if (e.KeyChar == ',' && (tbheight.Text.IndexOf(',') > -1 || tbheight.Text.Length == 0))
            {
                e.Handled = true;
            }
        }

        private void tbcount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
