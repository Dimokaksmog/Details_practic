﻿namespace Details
{
    partial class detailsMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(detailsMain));
            this.dtgCatalog = new System.Windows.Forms.DataGridView();
            this.tbpoiskname = new System.Windows.Forms.TextBox();
            this.tbpoiskmodel = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.butadd = new System.Windows.Forms.Button();
            this.butdel = new System.Windows.Forms.Button();
            this.butedit = new System.Windows.Forms.Button();
            this.butauth = new System.Windows.Forms.Button();
            this.butExcel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbnamesort = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cbmodelsort = new System.Windows.Forms.ComboBox();
            this.butupdate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgCatalog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dtgCatalog
            // 
            this.dtgCatalog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgCatalog.Location = new System.Drawing.Point(12, 12);
            this.dtgCatalog.Name = "dtgCatalog";
            this.dtgCatalog.Size = new System.Drawing.Size(871, 408);
            this.dtgCatalog.TabIndex = 0;
            // 
            // tbpoiskname
            // 
            this.tbpoiskname.Location = new System.Drawing.Point(271, 441);
            this.tbpoiskname.Name = "tbpoiskname";
            this.tbpoiskname.Size = new System.Drawing.Size(253, 20);
            this.tbpoiskname.TabIndex = 4;
            this.tbpoiskname.TextChanged += new System.EventHandler(this.tbpoiskname_TextChanged);
            // 
            // tbpoiskmodel
            // 
            this.tbpoiskmodel.Location = new System.Drawing.Point(12, 441);
            this.tbpoiskmodel.Name = "tbpoiskmodel";
            this.tbpoiskmodel.Size = new System.Drawing.Size(253, 20);
            this.tbpoiskmodel.TabIndex = 5;
            this.tbpoiskmodel.TextChanged += new System.EventHandler(this.tbpoiskmodel_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1102, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 42.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(892, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 65);
            this.label1.TabIndex = 7;
            this.label1.Text = "Детали";
            // 
            // butadd
            // 
            this.butadd.Enabled = false;
            this.butadd.Location = new System.Drawing.Point(889, 80);
            this.butadd.Name = "butadd";
            this.butadd.Size = new System.Drawing.Size(207, 41);
            this.butadd.TabIndex = 8;
            this.butadd.Text = "Добавить";
            this.butadd.UseVisualStyleBackColor = true;
            this.butadd.Click += new System.EventHandler(this.butadd_Click);
            // 
            // butdel
            // 
            this.butdel.Enabled = false;
            this.butdel.Location = new System.Drawing.Point(889, 127);
            this.butdel.Name = "butdel";
            this.butdel.Size = new System.Drawing.Size(207, 41);
            this.butdel.TabIndex = 9;
            this.butdel.Text = "Удалить";
            this.butdel.UseVisualStyleBackColor = true;
            this.butdel.Click += new System.EventHandler(this.butdel_Click);
            // 
            // butedit
            // 
            this.butedit.Enabled = false;
            this.butedit.Location = new System.Drawing.Point(889, 174);
            this.butedit.Name = "butedit";
            this.butedit.Size = new System.Drawing.Size(207, 41);
            this.butedit.TabIndex = 10;
            this.butedit.Text = "Редактирование";
            this.butedit.UseVisualStyleBackColor = true;
            this.butedit.Click += new System.EventHandler(this.butedit_Click);
            // 
            // butauth
            // 
            this.butauth.Location = new System.Drawing.Point(1102, 174);
            this.butauth.Name = "butauth";
            this.butauth.Size = new System.Drawing.Size(150, 41);
            this.butauth.TabIndex = 11;
            this.butauth.Text = "Авторизация";
            this.butauth.UseVisualStyleBackColor = true;
            this.butauth.Click += new System.EventHandler(this.butauth_Click);
            // 
            // butExcel
            // 
            this.butExcel.Location = new System.Drawing.Point(890, 222);
            this.butExcel.Name = "butExcel";
            this.butExcel.Size = new System.Drawing.Size(362, 51);
            this.butExcel.TabIndex = 12;
            this.butExcel.Text = "Экспорт в Excel";
            this.butExcel.UseVisualStyleBackColor = true;
            this.butExcel.Click += new System.EventHandler(this.butExcel_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 425);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Поиск по названию";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 425);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Поиск по модели";
            // 
            // cbnamesort
            // 
            this.cbnamesort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbnamesort.FormattingEnabled = true;
            this.cbnamesort.Items.AddRange(new object[] {
            "Очистить сортировку",
            "От А до Я",
            "От Я до А"});
            this.cbnamesort.Location = new System.Drawing.Point(533, 441);
            this.cbnamesort.Name = "cbnamesort";
            this.cbnamesort.Size = new System.Drawing.Size(150, 21);
            this.cbnamesort.TabIndex = 15;
            this.cbnamesort.SelectedIndexChanged += new System.EventHandler(this.cbnamesort_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(530, 424);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Сортировка по названию";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(686, 424);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(123, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Сортировка по модели";
            // 
            // cbmodelsort
            // 
            this.cbmodelsort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbmodelsort.FormattingEnabled = true;
            this.cbmodelsort.Items.AddRange(new object[] {
            "Очистить сортировку",
            "От А до Я",
            "От Я до А"});
            this.cbmodelsort.Location = new System.Drawing.Point(689, 441);
            this.cbmodelsort.Name = "cbmodelsort";
            this.cbmodelsort.Size = new System.Drawing.Size(150, 21);
            this.cbmodelsort.TabIndex = 17;
            this.cbmodelsort.SelectedIndexChanged += new System.EventHandler(this.cbmodelsort_SelectedIndexChanged);
            // 
            // butupdate
            // 
            this.butupdate.Location = new System.Drawing.Point(890, 279);
            this.butupdate.Name = "butupdate";
            this.butupdate.Size = new System.Drawing.Size(362, 51);
            this.butupdate.TabIndex = 19;
            this.butupdate.Text = "Обновить базу данных";
            this.butupdate.UseVisualStyleBackColor = true;
            this.butupdate.Click += new System.EventHandler(this.butupdate_Click);
            // 
            // detailsMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1264, 511);
            this.Controls.Add(this.butupdate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbmodelsort);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbnamesort);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.butExcel);
            this.Controls.Add(this.butauth);
            this.Controls.Add(this.butedit);
            this.Controls.Add(this.butdel);
            this.Controls.Add(this.butadd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tbpoiskmodel);
            this.Controls.Add(this.tbpoiskname);
            this.Controls.Add(this.dtgCatalog);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "detailsMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Склад деталей";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.detailsMain_FormClosing);
            this.Load += new System.EventHandler(this.detailsMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgCatalog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtgCatalog;
        private System.Windows.Forms.TextBox tbpoiskname;
        private System.Windows.Forms.TextBox tbpoiskmodel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button butadd;
        private System.Windows.Forms.Button butdel;
        private System.Windows.Forms.Button butedit;
        private System.Windows.Forms.Button butauth;
        private System.Windows.Forms.Button butExcel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbnamesort;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbmodelsort;
        private System.Windows.Forms.Button butupdate;
    }
}

